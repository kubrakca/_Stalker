using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour
{
    public Animator playerAnim;
    public Rigidbody playerRigid;
    public Transform playerTrans;
    public float walkSpeed, backwardSpeed, rotateSpeed;
    public GameObject weapon;

    private bool isWalking = false;

    void FixedUpdate()
    {
        
        if (Input.GetKey(KeyCode.W))
        {
            playerRigid.velocity = transform.forward * walkSpeed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            playerRigid.velocity = -transform.forward * backwardSpeed * Time.deltaTime;
        }
        else
        {
            playerRigid.velocity = Vector3.zero;
        }

        
        if (Input.GetKey(KeyCode.A))
        {
            playerTrans.Rotate(0, -rotateSpeed * Time.deltaTime, 0);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            playerTrans.Rotate(0, rotateSpeed * Time.deltaTime, 0);
        }
    }

    void Update()
    {
        
        if (Input.GetMouseButtonDown(0))
        {
            playerAnim.SetTrigger("fire");
            
        }

        
        if (Input.GetKeyDown(KeyCode.R))
        {
            playerAnim.SetTrigger("reload");
            
        }

        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKey(KeyCode.W))
        {
            isWalking = true;
        }
        else
        {
            isWalking = false;
        }
  
        if (!isWalking)
        {
            playerAnim.SetTrigger("idle");
        }
        else
        {
            playerAnim.ResetTrigger("idle");
        }

        if (Input.GetKey(KeyCode.W))
        {
            playerAnim.SetBool("walk",true);
        }
        else if (Input.GetKeyUp(KeyCode.W))
        {
            playerAnim.ResetTrigger("walk");
        }

        if (Input.GetKey(KeyCode.S))
        {
            playerAnim.SetTrigger("walkback");
        }
        else if (Input.GetKeyUp(KeyCode.S))
        {
            playerAnim.ResetTrigger("walkback");
        }
    }
}
